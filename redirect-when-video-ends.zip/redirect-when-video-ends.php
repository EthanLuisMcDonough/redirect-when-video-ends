<?php
/*
Plugin Name: Redirect when Video Ends
Plugin URI: https://github.com/EthanLuisMcDonough/redirect-when-video-ends
Description: A shortcode that allows you to embed an HTML5 video and redirect the page when the video is over
Version: 1.0
Author: Ethan Luis McDonough
Author URI: http://www.ethanmcdonough.com/
License: GPLv2 or later
Text Domain: redirect-when-video-ends
*/

function redOnVidFinish($atts) {
   $a = shortcode_atts(
           array(
              "controls" => "no", 
              "autoplay" => "no", 
              "src" => "",
              "link" => "",
              "target" => "_self", 
              "poster" => ""
           ), 
           $atts
      );
   
   $src = ($a['src'] != "") ? "src=\"" . $a['src'] ."\" " : "";
   $poster = ($a['poster'] != "") ? "poster=\"" . $a['poster'] ."\" " : "";
   $autoplay = ($a['autoplay'] == "no") ? "" : "autoplay ";
   $controls = ($a['controls'] == "no") ? "" : "controls ";
   $target = $a['target'];
   $link = ($a['autoplay'] != "") ? "onended=\"window.open('" . $a['link']. "', ' . $target . ');\"" : "";


   return "<video " . $autoplay . $controls . $src . $poster . $link . "></video>";
}

add_shortcode( 'redirvid', 'redOnVidFinish' );